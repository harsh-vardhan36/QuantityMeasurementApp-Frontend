import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
 
export interface UserProfile {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  imageUrl?: string;
  provider?: string;
  emailVerified?: boolean;
}
 
@Injectable({ providedIn: 'root' })
export class UserService {
  private readonly API = 'http://localhost:8080/api/user';
 
  constructor(private http: HttpClient) {}
 
  // GET /api/user/me — requires JWT (jwt-interceptor adds it automatically)
  getProfile(): Observable<UserProfile> {
    return this.http.get<UserProfile>(`${this.API}/me`);
  }
}
 



































